import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

public class SortCompratr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ArrayList<Emp> a1 =new ArrayList<>();
		
		HashSet<Integer> h =new HashSet<>();
		System.out.println(h.add(50));
		System.out.println(h.add(50));
		System.out.println(h.add(40));
		System.out.println(h.add(25));
		System.out.println(h.add(136));
		System.out.println(h.add(98));
		System.out.println(h.add(4));
		ArrayList<Integer> l1=new ArrayList<Integer>(h);
		
		//Collections.sort(l1);
		Iterator<Integer> i=l1.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
		System.out.println(l1);
		//System.out.println();
	}

}
