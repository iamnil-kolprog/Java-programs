
import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, Float> h1=new HashMap<>();
		h1.put(10,20.0f);
		h1.put(20,25.0f);
		h1.put(30,95.0f);
		h1.put(21,65.0f);
		h1.put(19,18.0f);
		h1.put(62,26.0f);
		
		Set<Integer> s=h1.keySet();
		System.out.println(s);
		
		Collection<Float> c= h1.values();
		System.out.println(c);
		
		
		Set<Entry<Integer,Float>> s1=h1.entrySet();
		for(Entry<Integer,Float> e:s1) {
			System.out.println(e.getKey()+"  "+e.getValue());
		
		}
	}

}
