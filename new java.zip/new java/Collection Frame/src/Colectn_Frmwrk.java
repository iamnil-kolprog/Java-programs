import java.util.ArrayList;
import java.util.Iterator;

public class Colectn_Frmwrk {
	public static void main(String[] args) {
		
		ArrayList<String> a1 =new ArrayList<String>();
		a1.add("java");
		a1.add("j2ee");
		a1.add("php");
		a1.add("python");
		
		Iterator<String> it = a1.iterator();
		while(it.hasNext()) {
			String s =it.next();
			System.out.println(s);
			if(s.equals("php"))
				it.remove();
		}
		System.out.println(a1);
	}
}
