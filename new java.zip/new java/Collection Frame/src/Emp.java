
public class Emp {
	int id;
	//float sal;
	String s;
	public Emp(int id, String s) {
		//super();
		this.id = id;
		//this.sal = sal;
		this.s = s;
	}
	public String toString() {
		return id+" "+" "+s;
		
	}
	
	

}
