import java.util.ArrayList;
import java.util.Iterator;

public class AL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Emp> a1=new ArrayList<Emp>();
		a1.add(new Emp(123,258.0f,"ffvbg"));
		a1.add(new Emp(456,2658.0f,"hjghghjg"));
		a1.add(new Emp(789,221.6f,"ewg"));
		
		Iterator<Emp> i= a1.iterator();
		while(i.hasNext()) {
		Emp e1=i.next(); 
		if(e1.id==456) {
			i.remove();
		}
		}
		System.out.println(a1);

	}

}
