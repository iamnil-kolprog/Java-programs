package com.nil.beans;

import java.time.LocalDate;

public class Employee {
	public long Emp_Id=((int)Math.random())*50+100;
	private String Emp_Name;
	public String Emp_Dept;
	public long Cell_No;
	public int Sal;
	public LocalDate dob;
	
	public Employee(String emp_Name, String emp_Dept, long cell_No, int sal, LocalDate dob) {
		super();
		Emp_Name = emp_Name;
		Emp_Dept = emp_Dept;
		Cell_No = cell_No;
		Sal = sal;
		this.dob = dob;
	}
	
}
