import java.lang.reflect.Array;
import java.util.Collections;
import java.util.Comparator;

import javax.lang.model.type.ArrayType;

public class CamparableLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Comparator< String> comp= (s1,s2) -> 
		Integer.compare(s1.length(), s2.length());
		
		String[] val = {"****","***","*","**"};
		Collections.sort(Array.asList(val), comp);
	}

}
