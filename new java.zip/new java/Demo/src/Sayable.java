
public interface Sayable {
	void say();
}
