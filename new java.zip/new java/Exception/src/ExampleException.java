import java.util.InputMismatchException;
import java.util.Scanner;

public class ExampleException {
	public static  void m(int a,int b) {
		
		try
		{
			int c=a/b;
			System.out.println(c);
			try {
				int z[]=new int[a];
				System.out.println(z[6]);
			}
			catch(ArrayIndexOutOfBoundsException e1) {
				System.out.println(e1);
			}
		}
		
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		try {
			String s1=null;
			System.out.println(s1.length());
			System.out.println("check");
		}
		catch(NullPointerException n)
		{
			System.out.println(n);
		}
		finally
		{
			System.out.println("Always");
		}
	}
	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
			int p=0 ,q=0;
			//p=s.nextInt();
			try {
				 p=s.nextInt();
				 q=s.nextInt();
				 s.close();
			}
			catch(InputMismatchException e2) {
				System.out.println(e2);
			
			}
		m(p,q);
		Example2  e1=new Example2();
		e1.dummy();
	}
}
