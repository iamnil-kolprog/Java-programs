
public class Example2 {
	int a=5,b=5;
	void dummy() {
		try {
			int c=a/b;
			System.out.println(c);
			throw new ArithmeticException();
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}
