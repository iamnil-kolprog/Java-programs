package com.cg.demo1;

import java.util.ArrayList;

public class MthdCheck {
	public String check(ArrayList<Integer> a) throws Exception {
		if(a.size()==0) {
			
			throw new Exception();
			}
		else
			return "success";
		
		}
	}

