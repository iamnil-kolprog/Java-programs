package com.cg.demo1;

import java.util.ArrayList;

public class Array {
	public static void main(String[] args) {
		
	
	
	ArrayList<Integer> l1=new ArrayList<Integer>();
	
	l1.add(50);
	l1.add(40);
	l1.add(25);
	l1.add(136);
	l1.add(98);
	l1.add(5);
	
	}
}
