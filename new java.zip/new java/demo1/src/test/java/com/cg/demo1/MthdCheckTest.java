package com.cg.demo1;

import java.util.ArrayList;

import junit.framework.TestCase;

public class MthdCheckTest extends TestCase {
	ArrayList<Integer> l1=new ArrayList<Integer>();
	
	
	MthdCheck m=null;
	protected void setUp() throws Exception {
		m=new MthdCheck();
	}

	protected void tearDown() throws Exception {
		m=null;
	}

	public void testCheck() throws Exception {
		//fail("Not yet implemented");
		assertEquals("success", m.check(l1));
	}

}
