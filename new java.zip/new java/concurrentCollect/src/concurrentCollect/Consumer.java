package concurrentCollect;

import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable{
	BlockingQueue bcq;
	
	
	public Consumer(BlockingQueue bcq) {
		//super();
		this.bcq = bcq;
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(bcq.remainingCapacity()>0) {
			System.out.println(bcq.size()+" Remaining capacity is"+bcq.remainingCapacity());
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/*if(bcq.size()==0) {
			
		}*/
	}

}
