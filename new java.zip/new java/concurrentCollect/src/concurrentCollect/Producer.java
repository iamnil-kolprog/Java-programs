package concurrentCollect;

import java.util.concurrent.BlockingQueue;

public class Producer implements Runnable {
	BlockingQueue bq;

	public Producer(BlockingQueue bq) {
		//super();
		this.bq = bq;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<8;i++) {
			System.out.println("value is "+i+" "+bq.offer(i));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	

}
