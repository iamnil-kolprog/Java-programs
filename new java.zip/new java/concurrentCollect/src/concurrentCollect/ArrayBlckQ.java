package concurrentCollect;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ArrayBlckQ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BlockingQueue bq=new ArrayBlockingQueue<>(5);
		Thread producer =new Thread(new Producer(bq));
		
		Thread consumer =new Thread(new Consumer(bq));
		producer.start();
		consumer.start();

	}

}
