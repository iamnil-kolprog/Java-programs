package com.cg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class MainHash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashmapDemo hd =new HashmapDemo();
		HashMap<Integer, String> map =new HashMap<>();
		
		map.put(50, "Nil");
		map.put(10, "Gaurav");
		map.put(30, "Sugu");
		map.put(90, "Gova");
		map.put(70, "Avi");
		map.put(20, "Rishi");
		map.put(25, "Hari");
		map.put(32, "Aditi");
		map.put(85, "Kiron");
		
		List<String> l=hd.getValues(map);
		
		Iterator<String > i= l.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
		//System.out.println(l);
		
	}

}
