package com.cg.coll3;

import java.util.Map;
import java.util.Scanner;

public class SquareMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SquareArray sqa = new SquareArray();
		Scanner s =new Scanner(System.in);
		System.out.println("Enter Total No. of element : ");
		int n=s.nextInt();
		
		int a[]=new int[n];
		for(int i=0;i<a.length;i++) {
			System.out.println("Enter "+i+"th element : ");
			a[i]=s.nextInt();
		}
		Map<Integer, Integer> mp=sqa.getSquares(a);
		for(Map.Entry<Integer, Integer> e:mp.entrySet()) {
			
			System.out.println("Square of "+e.getKey()+" is :"+e.getValue());
		}

	}

}
