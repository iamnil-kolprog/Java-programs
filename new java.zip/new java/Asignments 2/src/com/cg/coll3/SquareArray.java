package com.cg.coll3;

import java.util.HashMap;
import java.util.Map;

public class SquareArray {
	
	public Map<Integer, Integer> getSquares(int[] a){
		int sq;
		Map<Integer, Integer> mapsq =new HashMap<Integer, Integer>();
		for(int i=0;i<a.length;i++) {
			sq=a[i]*a[i];
			mapsq.put(a[i], sq);
		}
		return mapsq;
	}
}
