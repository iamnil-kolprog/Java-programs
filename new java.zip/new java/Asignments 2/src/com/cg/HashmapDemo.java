package com.cg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class HashmapDemo {
	
	public List<String> getValues(HashMap<Integer, String> map){
		Collection<String> c=map.values();
		List<String> list =new ArrayList<String>(c);
		Collections.sort(list);
		return list;
		
	}

}
