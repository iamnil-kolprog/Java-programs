package com.cg.coll2;

import java.util.HashMap;
import java.util.Map;

public class CountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] c= {'n','i','l','a','n','j','a','n'};
		CharCount cc=new CharCount();
		Map< Character, Integer> m =new HashMap<Character, Integer>();
		//System.out.println(cc.countCharacter(c));
		m=cc.countCharacter(c);
		for(Map.Entry<Character, Integer> e:m.entrySet()) {
			
			System.out.println("Total number of timmes"+e.getKey()+"present is :"+e.getValue());
		}
	}

}
