package com.cg.coll2;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CharCount {
	
	public  Map<Character, Integer> countCharacter(char[] c){
		/*Scanner s=new Scanner(System.in);
		int len=s.nextInt();*/
		Map<Character,Integer> map =new HashMap<Character, Integer>();
		for(int i=0;i<c.length;i++) {
			if(c[i]!='\0') {
				int count =1;
				for(int j=i+1;j<c.length;j++) {
					if(c[i]==c[j]) {
						count++;
						c[j]='\0';
					}
				}
				//System.out.println("Total number of "+c[i]+" present is : "+count);
				map.put(c[i], count);
			}
		}
		return map;
	}

}
