import java.util.Scanner;

public class ArrayLoop {
	public static void main(String[] args) {
		
	Scanner s =new Scanner(System.in);
	int a[] = new int[20];
	for(int i=0;i<a.length;i++) {
		System.out.println("Enter "+i+"th element");
		a[i]=s.nextInt();
	}
	for(int i=0;i<a.length;i++) {
		System.out.println("The "+i+"th element is="+a[i]);
	}
}
}
