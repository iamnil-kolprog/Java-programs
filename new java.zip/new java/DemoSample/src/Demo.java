
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login login =new Login();
		login.setUser("Nil");
		login.getUser();
		login.setPass("Nilanjan1111");
		System.out.println("password is="+login.getPass());

	}

}

