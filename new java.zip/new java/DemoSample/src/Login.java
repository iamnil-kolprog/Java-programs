class Login {
	private String user,pass;
	public void getUser()
	{
		System.out.println("username is="+user);
	}
	public void setUser(String uname) {
		user=uname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}

}
