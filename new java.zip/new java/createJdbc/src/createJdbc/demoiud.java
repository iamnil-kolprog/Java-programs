package createJdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class demoiud {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
			Statement stmt =con.createStatement();
			/*stmt.execute("create table emp1_tb (eid number(6),ename varchar2(20),esal number(6))");
			
			PreparedStatement ps =con.prepareStatement("insert into emp1_tb values(?,?,?)");
			ps.setInt(1, 105);
			ps.setString(2, "Dip");
			ps.setInt(3, 2000);
			ps.execute();*/
			stmt.execute("alter table emp1_tb add column ecell number(10)");
			PreparedStatement ps =con.prepareStatement("insert into emp1_tb values(?,?,?,?)");
			ps.setInt(1, 105);
			ps.setString(2, "Dip");
			ps.setInt(3, 2000);
			ps.setLong(4, 900000000);
			ps.execute();
			//stmt.execute("delete from emp1_tb");
			System.out.println("jjjj");
			ResultSet rs =stmt.executeQuery("select * from emp1_tb");
			while(rs.next()) {
				int eid=rs.getInt(1);
			 String ename=rs.getString(2);
			 int sal =rs.getInt(3);
			 int cell=rs.getInt(4);
				System.out.println(eid+" "+ename+" "+sal+" "+cell);
			}
			
	}
		catch(SQLException s) {
			System.out.println(s);
		}
	}
}
