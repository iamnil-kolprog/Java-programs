package createJdbc;
import java.sql.*;

public class createJdbc {
	public static void main(String[] args) throws  SQLException, ClassNotFoundException  {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
			Statement stmt =con.createStatement();
			//stmt.execute("create table Nil_tb (eid number(6),ename varchar2(20))");
			//stmt.execute("insert into Nil_tb values(101,'Nilanjan')");
			//stmt.execute("insert into Nil_tb values(102,'Dipanjan')");
			//stmt.execute("delete table Nil_tb");
			//PreparedStatement ps =con.prepareStatement("insert into Nil_tb values(?,?)");
			//ps.setInt(1, 105);
			//ps.setString(2, "Dip");
			//ps.execute();
			
			//stmt.executeUpdate("update Nil_tb set ename='Capg' where eid=105");
			//stmt.execute("alter table Nil_tb add column esal number(10)");
			
			stmt.execute("insert into Nil_tb(esal) values(2000) ");
			System.out.println("aaaaa");
			stmt.execute("insert into Nil_tb(esal) values(5000) where eid=102");
			stmt.execute("insert into Nil_tb(esal) values(8000) where eid=105");
			ResultSet rs =stmt.executeQuery("select * from Nil_tb");
			while(rs.next()) {
				int eid=rs.getInt(1);
			 String ename=rs.getString(2);
			 int sal =rs.getInt(3);
				System.out.println(eid+" "+ename+" "+sal);
				
			}
			
		}
		catch(SQLException s) {
			System.out.println(s);
		}
	}

}
