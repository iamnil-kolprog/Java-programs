import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Demo2 {
	public static void main(String[] args) throws IOException {
		FileOutputStream fo = new FileOutputStream("nilanjan.txt");
		String str="my name is nilanjan and working for capg";
		fo.write(str.getBytes());
		FileInputStream fi =new FileInputStream("nilanjan.txt");
		/*
		int i;
		while((i=fi.read())!=-1) {
			System.out.println((char)i);
			}
			*/
		try {
			
		
		DataOutputStream dos= new DataOutputStream(fo);
		dos.writeDouble(565.12);
		dos.writeInt(12);
		dos.writeFloat(20.11f);
		DataInputStream dis = new DataInputStream(fi);
		System.out.println(dis.readDouble());
		
		dis.readFloat();
		}
		catch(IOException e) {
			System.out.println(e);
			}
		finally
		{
			fo.close();
			fi.close();

		}

}
}
