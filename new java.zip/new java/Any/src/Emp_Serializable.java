import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Emp_Serializable {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		FileOutputStream fo =new FileOutputStream("Employee.ser");
		Emp e= new Emp();
		e.setId(1215);
		e.setName("Nil");
		e.setSal(5000.0f);
		ObjectOutputStream oos =new ObjectOutputStream(fo);
		oos.writeObject(e);
		FileInputStream fis =new FileInputStream("Employee.ser");
		ObjectInputStream ois =new ObjectInputStream(fis);
		Emp e1=(Emp)ois.readObject();
		System.out.println(e1);
		oos.close();
		fo.close();
		fis.close();
		ois.close();
	}
}

