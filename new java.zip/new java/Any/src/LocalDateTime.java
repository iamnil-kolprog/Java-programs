import java.time.LocalDate;
import java.time.Month;

public class LocalDateTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			LocalDate currentDate = LocalDate.now();
			LocalDate independanceDay = LocalDate.of(1947, Month.AUGUST, 15);
			
			System.out.println("Independance:" + independanceDay);
			System.out.println("Today :"+currentDate);
			System.out.println("Tommorow :"+currentDate.plusDays(1));
			System.out.println("Last Month :"+currentDate.minusMonths(1));
			System.out.println("Is Leap :"+currentDate.isLeapYear());
			System.out.println("Move To 30th day of Month: "+currentDate.withDayOfMonth(30));
			System.out.println("Number Of Day In This Month: "+currentDate.lengthOfMonth());
	}

}
