package com.util;

import java.awt.List;


import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import com.dao.BankDaoImpl;
import com.exception.AmountException;
import com.bean.CreateAccount;

public class BankCollections {
	
	Scanner in=new Scanner(System.in);
	ArrayList<CreateAccount> m=new ArrayList<>();
	CreateAccount account;
	ArrayBlockingQueue<String> q=new ArrayBlockingQueue<>(10);
	public java.util.List<CreateAccount> add(CreateAccount cr)
	{
		m.add(cr);
		return m;
	}
	public long balance(int d, java.util.List<CreateAccount> l)
	{
		long b=0;
		Iterator<CreateAccount> itr=l.iterator();
		
		while(itr.hasNext())
		{
			CreateAccount c=itr.next();
			if(d==c.getAccountno())
			{
				b=c.getBalance();
			}				
		}
		return b;
	}
	public long deposit(int a,long i,java.util.List<CreateAccount> l)
	{
		Iterator<CreateAccount> itr=l.iterator();
		
		while(itr.hasNext())
		{
			CreateAccount c=itr.next();
			if(a==c.getAccountno())
			{
				c.setBalance(c.getBalance()+i);
				i=c.getBalance();
			}				
		}
		transactions("you deposited amount "+i+" to your account with account number "+a+"\n");
		return i;
	}
	public long withdraw(int i,long a,java.util.List<CreateAccount> l)
	{
		Iterator<CreateAccount> itr=l.iterator();
		
		try {
			
		while(itr.hasNext())
		{
			CreateAccount c=itr.next();
			if(i==c.getAccountno())
			{
				if(c.getBalance()>a)
					{c.setBalance(c.getBalance()-a);
					a=c.getBalance();}
				else
					throw new AmountException();
			}				
		}
		transactions("you withdrew amount "+a+" to your account with account number "+i+"\n");
		return a;
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return a;
	}
	public long fundTransfer(int s, int a,long am,java.util.List<CreateAccount> l)
	{
		Iterator<CreateAccount> itr=l.iterator();
		long acc1=0,acc2=0;
		while(itr.hasNext())
		{
			
			CreateAccount c=itr.next();
			try{
			if(s==c.getAccountno())
			{
				if(c.getBalance()>am)
				{
				c.setBalance(c.getBalance()-am);
				acc1=c.getBalance();
				}
				else 
					throw new AmountException();
			}
			if(a==c.getAccountno())
			{
				c.setBalance(c.getBalance());
				acc2=c.getBalance();
			}}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		transactions("you transferred amount: "+am+" from your account with account number "+s+" to account number "+a+"\n");
		return acc1;
		
	}
	public ArrayBlockingQueue<String> transactions(String s)
	{
		q.add(s);
		
		return q;
		
	}
	
}
