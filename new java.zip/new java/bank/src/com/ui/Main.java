package com.ui;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;

import com.bean.CreateAccount;
import com.service.BankService;
import com.service.BankServiceImpl;

public class Main {
	
	public static void main(String[] args) {
		List<CreateAccount> lis=new ArrayList<>();
		ArrayBlockingQueue<String> q=new ArrayBlockingQueue<>(100);
		CreateAccount cr=null;
		String custname,transactions=null;
		String city;
		String cellnumber;
		BankServiceImpl bs=new BankServiceImpl();
		System.out.println("WELCOME");
		Scanner in=new Scanner(System.in);
		while(true){
		System.out.println("Select the operation you want to do:");
		System.out.println("1.create account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transactions");
		System.out.println("7.Exit");
		int option=0;
		int balance=0;
		option=in.nextInt();
		int accountno;
		
		switch (option) {
			
		case 1:
				
					  cr=new CreateAccount();
					  accountno = (int) (1000*Math.random());
					  cr.setAccountno(accountno);
					  System.out.println("Enter your name:");
					  custname=in.next();
					  cr.setCustname(custname);
					  System.out.println("Enter your city:");
					  city=in.next();
					  cr.setCity(city);
					  System.out.println("Enter your CellNumber:");
					  cellnumber=in.next();				 
					  cr.setCellnumber(cellnumber);
					  lis.addAll(bs.addAccount(cr));		 
					  System.out.println("Successfully created your account:");
					  System.out.println("Your account number is:"+accountno);				 				    
				
			break;
		case 2:
				System.out.println("Enter the account number:");
				int num=in.nextInt();
				//System.out.println(l);
				System.out.println(bs.viewDetails(num,lis));
				
			break;	
		case 3:
			System.out.println("Enter the account number:");
			int n=in.nextInt();
			System.out.println("Enter the amount to be deposited:");
			long amount=in.nextLong();
			System.out.println("Your available balance is:"+bs.deposit(n, amount, lis));
			q.addAll(bs.transactions("/n"));
			break;
		case 4:
			System.out.println("Enter the account number:");
			int n1=in.nextInt();
			System.out.println("Enter the amount to be withdrawn:");
			long amount1=in.nextLong();
			System.out.println("Your available balance is:"+bs.withdraw(n1, amount1, lis));
			q.addAll(bs.transactions("/n"));
			break;
		case 5:
			System.out.println("Enter your account number:");
			int ns=in.nextInt();
			System.out.println("Enter account number you want to transfer:");
			int nr=in.nextInt();
			System.out.println("Enter the amount to be transferred:");
			long amt=in.nextLong();
			System.out.println("Your available balance is:"+bs.fundTransfer(ns,nr, amt, lis));
			q.addAll(bs.transactions("/n"));
			break;
		case 6:
			Set<String> s=new LinkedHashSet<>();
			s.addAll(q);
			System.out.println(s);
			break;
		case 7:
			System.out.println("Thank you! for using our service.");
			break;
		default:
			System.out.println("Enter valid option");
			break;
		}
	}
	}
}
