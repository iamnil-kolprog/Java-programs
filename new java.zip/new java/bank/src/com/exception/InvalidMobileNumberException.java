package com.exception;

public class InvalidMobileNumberException extends Exception {

	public InvalidMobileNumberException() {
		super();
		
	}

	@Override
	public String toString() {
		return "InvalidMobileNumberException";
	}
	
}
