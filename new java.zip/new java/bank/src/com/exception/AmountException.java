package com.exception;

public class AmountException extends Exception{

	public AmountException() {
		super();
		
	}

	@Override
	public String toString() {
		return "Insufficient balance!!";
	}
	
}
