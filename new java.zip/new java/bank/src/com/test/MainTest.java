package com.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bean.CreateAccount;
import com.service.BankServiceImpl;

public class MainTest {
	CreateAccount c,b;
	 
	List<CreateAccount> li=new ArrayList<>();
	BankServiceImpl bs=new BankServiceImpl();
	Iterator<CreateAccount> itr;
	long bal=0;
	@Before
	public void setUp() throws Exception {
		 c=new CreateAccount(1,"nil","kol","7070342321",10000);		
		 b=new CreateAccount(10, "sugu", "chenn", "8226281908", 10000);
		 	li.addAll(bs.addAccount(c));
			li.addAll(bs.addAccount(b));	
	}

	@After
	public void tearDown() throws Exception
	{
		
	}
	
	@Test
	public void testAddAccount()
	{
		
		
	}
	
	@Test
	public void testViewDetails() 
	{
		 bal=bs.viewDetails(1, li);
		assertEquals(100000, bal);
	}
	@Test
	public void testDeposit()
	{
		bal=bs.deposit(1, 2000, li);
		//itr=li.iterator();
		
		assertEquals(102000,bal);	
	}
	@Test
	public void testWithdraw()
	{
		System.out.println(li);
		bal=bs.withdraw(1, 20000, li);		 
		assertEquals(80000, bal);
	}
	@Test
	public void testFundTransfer()
	{		
		bal=bs.fundTransfer(1,10, 20000, li);
		assertEquals(80000, bal);	
	}

}
