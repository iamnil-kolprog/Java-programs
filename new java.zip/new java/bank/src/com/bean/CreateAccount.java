package com.bean;

import java.util.concurrent.ArrayBlockingQueue;

public class CreateAccount {
	private int accountno;
	private String custname;
	private String city;
	private String cellnumber;
	private long balance=0;

	public CreateAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CreateAccount(int accountno, String custname, String city, String cellnumber, long balance) {
		super();
		this.accountno = accountno;
		this.custname = custname;
		this.city = city;
		this.cellnumber = cellnumber;
		this.balance = balance;
	}

	public int getAccountno() {
		return accountno;
	}

	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCellnumber() {
		return cellnumber;
	}

	public void setCellnumber(String cellnumber) {
		this.cellnumber = cellnumber;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account Details: [accountno=" + accountno + ", custname=" + custname + ", city=" + city + ", cellnumber="
				+ cellnumber + " Balance"+balance+"\n]";
	}
}
