package com.cg.eis.exception;

import java.util.Scanner;

public class Main_Employee_Exception  {

	public static void main(String[] args) throws EmployeeException {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("Enter Your Salary : ");
		int Sal=s.nextInt();
		EmployeeException ee=new EmployeeException(Sal);
		if(Sal<3000) {
			try {
			throw new EmployeeException(Sal);}
			catch(EmployeeException e) {
				System.out.println(e);
				System.out.println("Inavalid");
			}
		}
		else
			System.out.println("Salary is "+Sal);

	}

}
