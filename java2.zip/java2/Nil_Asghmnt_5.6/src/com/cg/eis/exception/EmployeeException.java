package com.cg.eis.exception;
public class EmployeeException extends Exception {
	private int salary;

	public EmployeeException(int sal) {
		// TODO Auto-generated constructor stub
		salary=sal;
	}
	public String toString() {
		return "salary is "+salary+ " must be greater than 3000";
	}

}
