
public class SortReverse {
	public int[] getSorted(int[] a) {
		System.out.println("Afetr reverse");
		for(int i=a.length-1;i>=0;i--) {
			System.out.println(a[i]);
		}
		
		int len=a.length;
		int temp;
		
		for(int r=0;r<len-1;r++) {
			for(int i=0;i<len-1-r;i++) {
				if(a[i]>a[i+1]) {
					temp=a[i];
					a[i]=a[i+1];
					a[i+1]=temp;
				}
			}
		}
		return a;
	}
}
