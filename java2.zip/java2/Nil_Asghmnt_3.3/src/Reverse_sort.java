import java.util.Scanner;

public class Reverse_sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner(System.in);
		System.out.println("Enter the no. of element :");
		int n=s.nextInt();
		int a[]=new int[n];
		for(int i=0;i<a.length;i++) {
			a[i]=s.nextInt();
		}
		s.close();
		SortReverse sr =new SortReverse();
		sr.getSorted(a);
		System.out.println("After Sort:");
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}

}
