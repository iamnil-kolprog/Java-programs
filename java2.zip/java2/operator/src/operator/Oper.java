package operator;
import java.util.Scanner;
public class Oper {

	public static void main(String ar[]) {
		Scanner s =new Scanner(System.in);
		Cal c= new Cal();
		boolean a=true;
		while(a)
		 {
			System.out.println("press 1 for addition \n 2 for subtraction\n"
					+ "3 for multiplication \n "
					+ "4 for division");
			int n=s.nextInt();
			switch(n) {
			case 1:
				c.add();
				break;
			case 2:
				c.sub();
				break;
			case 3:
				c.mul();
				break;
			case 4:
				c.div();
				break;
			default:
				System.out.println("Invalid choice");
				a=false;
				
			}
		}
	}
}
