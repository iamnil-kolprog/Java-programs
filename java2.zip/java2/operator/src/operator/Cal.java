package operator;

public class Cal {
	int a=100;
	int b=20,res;
	public void add() {
		res=a+b;
		System.out.println("result is="+res);
	}
	public void sub() {
		res=a-b;
		System.out.println("result is="+res);
	}
	public void mul() {
		res=a*b;
		System.out.println("result is="+res);
	}
	public void div() {
		res=a/b;
		System.out.println("result is="+res);
	}

}
