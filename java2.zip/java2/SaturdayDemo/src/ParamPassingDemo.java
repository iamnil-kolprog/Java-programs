 class Apple {
	 public String color="green";
}
 public class ParamPassingDemo{
	 public static void changeColor(Apple apple) {
		// apple =new Apple();			//will create new class object
		 apple.color="red";
		 System.out.println(apple.color);
		 
	 }
	 public static void main(String[] args) {
		Apple apple =new Apple();
		System.out.println("color :"+apple.color);
		changeColor(apple);
		System.out.println("color :"+apple.color);
	}
 }
