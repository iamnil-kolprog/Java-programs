
public class Main {

	public static void main(String[] args) {
		/*// TODO Auto-generated method stub
		int x=5;
		change(x);
		System.out.println(x);;

	}
	public static void change(int x) {
		x=10;*/
		String s="nilanjan";
		s=s.substring(0, (s.length()/2)).toUpperCase();
		System.out.println(s);
	}

}
