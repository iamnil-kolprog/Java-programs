
public class StringSort {

	public String[] sortAlpha(String s[]) {
		String temp=null;
		int len=s.length;
		for(int round=0;round<len-1;round++) {
			for(int i=0;i<len-1-round;i++) {
				if((s[i].toLowerCase()).compareTo((s[i+1].toLowerCase()))>0) {
					temp=s[i];
					s[i]=s[i+1];
					s[i+1]=temp;
				}
			}
		}
		for(int i=0;i<len;i++) {
			int l=s[i].length();
			//System.out.println(l);
			if(l%2==0) {
				s[i]=s[i].substring(0, (l/2)).toUpperCase()+s[i].toLowerCase().substring(((l/2)), l);
				
			}
			else
			{
				s[i]=s[i].substring(0, (l/2)+1).toUpperCase()+s[i].toLowerCase().substring(((l/2)+1),l);
			}
			
		}
		return s;
	}
	

}
