
public class Main_Sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringSort s1=new StringSort();
		String s[]= {"nila","hari","kiRON","SUGumar"};
		s1.sortAlpha(s);
		for(int i=0;i<s.length;i++) {
		System.out.println(s[i]);
		}

	}

}
