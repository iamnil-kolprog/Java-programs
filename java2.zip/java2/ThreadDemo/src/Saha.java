
public class Saha {

	public void print() {
		// TODO Auto-generated method stub
		synchronized(this)
		{
			for(int i=0;i<5;i++) {
				System.out.println("My Thread");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	

}
class A implements Runnable() {
	public void run() {
		
	}
}