import java.lang.Thread;
public class Nil extends Thread{
	public void run() {
		for(int i=0;i<5;i++) {
		System.out.println("NIL");
		
		}
	}

}
class Nila extends Thread{
	public void run() {
		for(int i=0;i<5;i++) {
		System.out.println("Nilanjan Thread");
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException e) {
			System.out.println(e);
		}
		}
	}
}
 