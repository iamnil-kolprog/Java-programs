
public class DemoOfDaemon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Nila n1 =new Nila();
		n1.setDaemon(true);
		n1.start();
		 
		for(int i=0;i<5;i++) {
			System.out.println("Main Thread");
			try{
					Thread.sleep(300);
			}
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
	}

}
