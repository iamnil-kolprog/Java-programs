
public class SynchrnizeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Saha s=new Saha();
		Thread t=new Thread(s);
		t.start();
		for(int j=0;j<5;j++) {
			System.out.println("main");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
