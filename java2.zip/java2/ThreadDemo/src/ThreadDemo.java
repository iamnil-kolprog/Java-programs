
public class ThreadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Nil n= new Nil();
		n.start();
		for(int i=0;i<5;i++) {
			System.out.println("Main Thread");
		}
		//n.start();
	}

}
