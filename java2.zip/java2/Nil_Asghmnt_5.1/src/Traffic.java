import java.util.Scanner;

public class Traffic {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("press red or yellow or green");
		String s=sc.next();
		switch(s) {
		case "red" :
			System.out.println("stop");
			break;
		case "yellow" :
			System.out.println("ready");
			break;
		case "green" :
			System.out.println("go");
			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}
		///System.out.println(s);
	}
}
