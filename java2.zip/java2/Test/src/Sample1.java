
public class Sample1 {

	private String uN,pW;
	
	public Sample1() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Default Constructor"); 
	}
	
	public Sample1(String uN, String pW) {
		super();
		this.uN = uN;
		this.pW = pW;
		System.out.println(uN+"\n"+pW);
	}

	public static void main(String[] args) {
		//Sample1 s = new Sample1();
		Sample1 s1= new Sample1("nil", "132135456");
	}
	

}
