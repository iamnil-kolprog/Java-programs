import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatcherDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String in="Shop,Mop,Hopping,Chopping";
		Pattern pattern =Pattern.compile("hop");
		Matcher matcher =pattern.matcher(in);
		System.out.println(matcher.matches());
		while(matcher.find()) {
			System.out.println(matcher.group()+":"+matcher.start()+":"+matcher.end());*/
		Scanner sc =new Scanner(System.in);
		String s=sc.next();
		MatcherDemo md =new MatcherDemo();
		System.out.println(md.isName(s));
		}
	public boolean isName(String s) {
		Pattern patName =Pattern.compile("[A-Z][a-z]{2,}");
		Matcher mat = patName.matcher(s);
		return mat.matches();
	}
	}


