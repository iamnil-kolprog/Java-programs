package mpt;

public class demo {
	public static void main(String[] args) {
		System.out.println(00%12);
	}
}
