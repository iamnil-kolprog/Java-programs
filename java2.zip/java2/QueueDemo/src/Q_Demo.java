import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;

public class Q_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<Integer> q=new LinkedList<Integer>();
		q.add(200);
		q.add(65);
		q.offer(58);
		q.add(50);
		q.add(90);
		System.out.println(q);
		System.out.println(q.peek());
		System.out.println(q.poll());
		System.out.println(q);
		q.addFirst(100);
		q.addLast(5);
		System.out.println(q);
		System.out.println(q.element());
		System.out.println(q.poll());
		System.out.println(q.remove(58));
		System.out.println(q);
		
		
		Iterator<Integer> i1=q.descendingIterator();	//Backward Traversing not descending order
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
	}

}
/*class Mysort implements Comparator<Integer>{

	@Override
	public int compare(Integer o1, Integer o2) {
		// TODO Auto-generated method stub
		return o2.compareTo(o1);
	}
	
}*/
