
public class Count_Char {
	public void countChar(char a[]) {
		int j;
		for(int i=0;i<a.length;i++) {
			int count=1;
			if(a[i]!='\0') {
				for(j=i+1;j<a.length;j++) {
					if(a[i]==a[j]) {
						count++;
						a[j]='\0';
					}
				}
				System.out.println("the no. of "+a[i]+"is"+count);	
			}
			
		}
	}
}
