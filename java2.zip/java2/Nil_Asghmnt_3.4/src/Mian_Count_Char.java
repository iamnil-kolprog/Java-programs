
public class Mian_Count_Char {
	public static void main(String[] args) {
		Count_Char c=new Count_Char();
		c.countChar(new char[] {'n','i','l','a','n','j','a','n'});
	}

}
