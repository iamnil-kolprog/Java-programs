
public class AgeException extends Exception {
	private int age;
	public AgeException(int a) {
		// TODO Auto-generated constructor stub
		age=a;
	}
	public String toString() {
		return age+" is an invalid age";
		}
	
}
