import java.util.Scanner;

public class Excep  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		s.close();
		
		if(a<15) {
			try {
				throw new AgeException(a);
			}
			catch(AgeException e) {
				System.out.println(e);
				System.out.println("Not Eligible");
			}
		
	}
		else
		{
			System.out.println("Eligible");
		}
		
	}

}
