

public class Main_Excep {
	public static void main(String[] args)  {
	
		//Scanner S=new Scanner(System.in);
/*		System.out.println("Enter your first and last name :");
		String First_Name=S.next();
		String Last_Name=S.next();
*/		
		Main_Excep me=new Main_Excep();
		Main_Excep me1=new Main_Excep();
		me.Check("Nil", "");
		
		me1.Check("Nil", "saha");
		
	}
	public void Check(String First_Name,String Last_Name) {
		if(First_Name.equals("") || Last_Name.equals("")) {
			try {
				throw new Name_Val_Excp(First_Name, Last_Name);
			}
			catch(Name_Val_Excp n) {
				System.out.println(n);
				System.out.println("Name can't be blank");
			}
		}
		else
			System.out.println("Succesfully Submitted");
	}

}
