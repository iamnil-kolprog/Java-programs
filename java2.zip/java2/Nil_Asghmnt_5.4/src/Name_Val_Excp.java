import org.omg.CORBA.PRIVATE_MEMBER;

public class Name_Val_Excp extends Exception {
	private String Fn;
	private String Ln;
	public Name_Val_Excp(String fn,String ln) {
		Fn=fn;
		Ln=ln;
		
	}
	public String toString() {
		return "First name is "+Fn+"Last name is "+Ln;
	}

}
