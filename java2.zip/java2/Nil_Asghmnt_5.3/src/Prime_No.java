import java.util.Scanner;

public class Prime_No {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the no. :");
		int n=s.nextInt();
		s.close();
		boolean temp=false;
		System.out.println(2);
		for(int i=3;i<=n;i++) {
			for(int j=2;j<i;j++) {
				if(i%j==0) {
					temp=false;
					break;
				}
				else
					temp=true;
			}
			if(temp) {
				System.out.println(i);
			}
		}
	}

}
