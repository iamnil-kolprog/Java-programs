
public class Pr_NO {
	public int printPrime(int n) {
		for(int i=2;i<=n;i++) {
			for(int j=2;j<i;j++) {
				if(i%j!=0) {
					return i;
				}
			}
			
		}
		return 0;
	}

}
