public class fibbo{
	public int Non_recur_fibbo(int n) {
		int a=1,b=1;
		int c = 0;
		if(n==1 || n==2)
			return a;
		else
		{
			for(int i=3;i<=n;i++) {
				c=a+b;
				a=b;
				b=c;
			}
			return c;
		
		}
	}
	public int Recur_fibbo(int n) {
		if(n==1 ||n==2)
			return 1;
		else
			return Recur_fibbo(n-1)+Recur_fibbo(n-2);
		
	}
}